#import <UIKit/UIKit.h>
#import "MSHView.h"

@interface MSHDotView : MSHView

@property (nonatomic, assign) CGFloat barSpacing;

@end