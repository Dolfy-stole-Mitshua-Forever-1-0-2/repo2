#import <UIKit/UIKit.h>
#import "MSHView.h"

@interface MSHBarView : MSHView

@property (nonatomic, assign) CGFloat barCornerRadius;
@property (nonatomic, assign) CGFloat barSpacing;

@end